# Ensure all necessary imports are present
import vertexai
from vertexai.generative_models import GenerativeModel
from google.cloud import bigquery
from google.cloud import dataform_v1beta1
import json
import re
import os
from crewai import Agent, Task, Workflow, Client

# Initialize CrewAI client
crewai_client = Client()

# Define CrewAI agents
class OrchestratorAgent(Agent):
    def __init__(self, project_id, location, model_name):
        super().__init__()
        self.project_id = project_id
        self.location = location
        self.model_name = model_name

    @crewai_client.on_start
    async def handle_request(self, task: Task):
        user_request = task.get_input("user_request")
        print(f"Received user request: {user_request}")

        # Create pipeline creation task
        pipeline_task = Task(
            name="create_pipeline",
            input={"user_request": user_request},
        )
        # Send the task to the PipelineAgent
        await self.send(pipeline_task, agent_name="PipelineAgent")


class PipelineAgent(Agent):
    def __init__(self, project_id, location, model_name):
        super().__init__()
        vertexai.init(project=project_id, location=location)
        self.model = GenerativeModel(model_name)
        self.bigquery_client = bigquery.Client(project=project_id)
        self.project_id = project_id

    def query_information_schema(self, dataset_name=None, table_name=None):
        """
        Queries BigQuery information_schema to retrieve datasets, tables, and columns.
        """
        if not dataset_name:
            query = f"""
            SELECT schema_name 
            FROM `{self.project_id}.region-us.INFORMATION_SCHEMA.SCHEMATA`
            """
            return [row.schema_name for row in self.bigquery_client.query(query)]

        if not table_name:
            query = f"""
            SELECT table_name
            FROM `{self.project_id}.{dataset_name}.INFORMATION_SCHEMA.TABLES`
            """
            return [row.table_name for row in self.bigquery_client.query(query)]

        query = f"""
        SELECT column_name, data_type
        FROM `{self.project_id}.{dataset_name}.INFORMATION_SCHEMA.COLUMNS`
        WHERE table_name = '{table_name}'
        """
        return [{"name": row.column_name, "type": row.data_type} for row in self.bigquery_client.query(query)]

    def handle_user_request(self, user_request):
        """
        Handles the user request using Vertex AI to extract details and ask for missing information.
        """
        prompt = f"""
        You are a data engineering assistant. Analyze the following 
        user request and extract the following information in JSON format: 

        {{
        "source_tables": [
            {{
            "dataset": "dataset_name",
            "table": "table_name"
            }},
            {{
            "dataset": "dataset_name",
            "table": "table_name"
            }}
        ],
        "target_table": "dataset_name.table_name",
        "transformations": {{
            "transformation_description": "transformation_details"
        }}
        }}

        Request: "{user_request}"
        """
        response = self.model.generate_content(prompt)
        response_content = response.text.strip()
        try:
            return json.loads(response_content)
        except json.JSONDecodeError:
            return {"error": "Invalid JSON response from LLM"}

    @crewai_client.on_task("create_pipeline")
    async def create_pipeline(self, task: Task):
        user_request = task.get_input("user_request")

        # Parse the request with LLM
        parsed_request = self.handle_user_request(user_request)
        if "error" in parsed_request:
            # Handle error by sending a message back to the orchestrator
            await self.send(
                Task(
                    name="handle_follow_up",
                    input={
                        "user_request": user_request,
                        "parsed_request": parsed_request,
                    },
                ),
                agent_name="OrchestratorAgent",
            )
            return

        # Extract details from the parsed request
        source_tables = parsed_request.get("source_tables", [])
        target_table = parsed_request.get("target_table", "")
        transformations = parsed_request.get("transformations", {})

        # Generate pipeline code
        pipeline_code = self.generate_pipeline_code(source_tables, target_table, transformations)

        # Create dataform task
        dataform_task = Task(
            name="create_dataform_files",
            input={"pipeline_code": pipeline_code, "target_table": target_table},
        )
        # Send the task to the DataformAgent
        await self.send(dataform_task, agent_name="DataformAgent")

    def generate_pipeline_code(self, source_tables, target_table, transformations):
        """
        Generates a multi-layer data pipeline using Dataform SQLX.
        """
        prompt = f"""
        Generate a multi-layer Dataform SQLX pipeline for the following details:

        1. Source tables: {json.dumps(source_tables, indent=2)}
        2. Target table: {target_table}
        3. Transformations: {json.dumps(transformations, indent=2)}
        """
        response = self.model.generate_content(prompt)
        return response.text.strip()


class DataformAgent(Agent):
    def __init__(self, project_id):
        super().__init__()
        self.project_id = project_id

    async def upload_and_compile_files(self, files, workspace_name):
        """
        Uploads and compiles the files in Dataform.
        """
        client = dataform_v1beta1.DataformClient()
        repository_path = client.repository_path(self.project_id, "us-central1", "agent")
        workspace_path = client.workspace_path(self.project_id, "us-central1", "agent", workspace_name)

        for file in files:
            file_path = file.get("path")
            file_content = file.get("content")
            try:
                request = dataform_v1beta1.WriteFileRequest(
                    workspace=workspace_path,
                    path=file_path,
                    contents=file_content.encode("utf-8"),
                )
                client.write_file(request=request)
            except Exception as e:
                print(f"Error uploading file '{file_path}': {e}")

        # Compilation
        compilation_result = dataform_v1beta1.CompilationResult()
        compilation_result.git_commitish = "main"
        compilation_result.workspace = workspace_path

        request = dataform_v1beta1.CreateCompilationResultRequest(
            parent=repository_path, compilation_result=compilation_result
        )
        result = client.create_compilation_result(request=request)

        if result.compilation_errors:
            print(f"Compilation errors: {result.compilation_errors}")
            # Handle errors appropriately


# Initialize and run workflow
project_id = "samets-ai-playground"
model_name = "gemini-1.5-pro-002"
location = "europe-west4"

orchestrator_agent = OrchestratorAgent(project_id, location, model_name)
pipeline_agent = PipelineAgent(project_id, location, model_name)
dataform_agent = DataformAgent(project_id)

workflow = Workflow(
    name="data-pipeline-workflow",
    agents=[orchestrator_agent, pipeline_agent, dataform_agent],
)

crewai_client.run(workflow)
